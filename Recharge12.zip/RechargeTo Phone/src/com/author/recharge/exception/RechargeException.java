package com.author.recharge.exception;

public class RechargeException extends Exception{
	private static final long serialVersionUID = -9169087956619494264L;

	public RechargeException(String message) 
	{
		
		super(message);
	}
}
