package com.author.recharge.dao;

public interface IQueryMapper {
	public static final String insertQuery="insert into rechargeInfo values(?,?,?,?,?,?)";
	public static final String selectPlans="select * from plans";
	public static final String seqQuery="select rechId_sequence.nextval from dual";
	public static final String userDetailsQuery="select * from rechargeInfo where rech_Id=?";
	public static final String retrieveAmountQuery="select amount from plans where planName=?";
	public static final String validPlanQuery="select count(*) from plans where planName=?";
	public static final String validRechIdQuery="select count(*) from rechargeInfo where rech_Id=?";
}
